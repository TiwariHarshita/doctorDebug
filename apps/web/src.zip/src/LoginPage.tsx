import { useState } from "react";
import axios from "axios";
import { Bug, Loader2, ShieldCheck, Sparkles, Zap } from "lucide-react";
import { api } from "./lib/api";

type LoginPageProps = {
  onLoginSuccess: () => void;
  onGoToRegister?: () => void;
};

function LoginPage({ onLoginSuccess, onGoToRegister }: LoginPageProps) {
  const [email, setEmail] = useState("achint@example.com");
  const [password, setPassword] = useState("password123");
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const handleLogin = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    try {
      setIsLoading(true);
      setErrorMessage("");

      const response = await api.post("/auth/login", {
        email,
        password
      });

      const token =
        response.data.data?.token ||
        response.data.token ||
        response.data.data?.accessToken;

      if (!token) {
        throw new Error("Login succeeded but token was not returned");
      }

      localStorage.setItem("debugpilot_token", token);
      onLoginSuccess();
    } catch (error: unknown) {
      if (axios.isAxiosError(error)) {
        setErrorMessage(error.response?.data?.message || "Failed to login");
      } else if (error instanceof Error) {
        setErrorMessage(error.message);
      } else {
        setErrorMessage("Failed to login");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <main className="flex min-h-screen bg-[#F7F8FB] p-5">
      <section className="hidden flex-1 overflow-hidden rounded-[36px] bg-[#101010] p-10 text-white lg:block">
        <div className="flex h-full flex-col justify-between">
          <div>
            <div className="mb-14 flex items-center gap-3">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#FFF4C7] text-[#111111]">
                <Zap size={24} />
              </div>

              <div>
                <p className="text-lg font-extrabold">DebugPilot</p>
                <p className="text-sm font-medium text-white/45">
                  AI debugging SaaS
                </p>
              </div>
            </div>

            <h1 className="max-w-xl text-[56px] font-extrabold leading-[0.95] tracking-[-0.06em]">
              Monitor backend errors like a real SaaS team.
            </h1>

            <p className="mt-7 max-w-md text-base font-medium leading-7 text-white/55">
              Capture API crashes, group repeated incidents, inspect stack
              traces, and generate debugging suggestions from one clean
              dashboard.
            </p>
          </div>

          <div className="grid grid-cols-3 gap-4">
            <div className="rounded-[28px] bg-white/10 p-5">
              <Bug className="mb-5 text-[#FFE1E1]" size={25} />
              <p className="text-sm font-extrabold">Track errors</p>
              <p className="mt-2 text-xs font-medium leading-5 text-white/45">
                Real backend events from your SDK.
              </p>
            </div>

            <div className="rounded-[28px] bg-white/10 p-5">
              <ShieldCheck className="mb-5 text-[#DDF8E7]" size={25} />
              <p className="text-sm font-extrabold">Resolve faster</p>
              <p className="mt-2 text-xs font-medium leading-5 text-white/45">
                Group incidents using fingerprints.
              </p>
            </div>

            <div className="rounded-[28px] bg-white/10 p-5">
              <Sparkles className="mb-5 text-[#EEF2FF]" size={25} />
              <p className="text-sm font-extrabold">AI analysis</p>
              <p className="mt-2 text-xs font-medium leading-5 text-white/45">
                Get root cause and fix checklists.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="flex flex-1 items-center justify-center px-4">
        <div className="w-full max-w-[470px]">
          <div className="rounded-[36px] bg-white p-8 shadow-sm ring-1 ring-black/5">
            <div className="mb-8">
              <h2 className="text-[34px] font-extrabold tracking-[-0.05em]">
                Welcome back
              </h2>
              <p className="mt-2 text-sm font-medium leading-6 text-[#6B7280]">
                Login to your DebugPilot workspace.
              </p>
            </div>

            {errorMessage && (
              <div className="mb-5 rounded-[22px] bg-[#FFE1E1] p-4 text-sm font-bold text-[#DC2626]">
                {errorMessage}
              </div>
            )}

            <form onSubmit={handleLogin} className="space-y-5">
              <div>
                <label className="mb-2 block text-sm font-extrabold text-[#111111]">
                  Email
                </label>
                <input
                  value={email}
                  onChange={(event) => setEmail(event.target.value)}
                  className="h-13 w-full rounded-[20px] bg-[#F7F8FB] px-5 py-4 text-sm font-bold outline-none ring-1 ring-black/5 focus:ring-2 focus:ring-[#111111]"
                  placeholder="you@example.com"
                  type="email"
                  required
                />
              </div>

              <div>
                <label className="mb-2 block text-sm font-extrabold text-[#111111]">
                  Password
                </label>
                <input
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                  className="h-13 w-full rounded-[20px] bg-[#F7F8FB] px-5 py-4 text-sm font-bold outline-none ring-1 ring-black/5 focus:ring-2 focus:ring-[#111111]"
                  placeholder="Enter password"
                  type="password"
                  required
                />
              </div>

              <button
                disabled={isLoading}
                className="flex h-14 w-full items-center justify-center gap-2 rounded-[22px] bg-[#111111] text-sm font-extrabold text-white transition hover:bg-black disabled:cursor-not-allowed disabled:opacity-60"
              >
                {isLoading && <Loader2 className="animate-spin" size={18} />}
                {isLoading ? "Logging in..." : "Login"}
              </button>
            </form>

            <p className="mt-6 text-center text-sm font-semibold text-[#6B7280]">
              New to DebugPilot?{" "}
              <button
                onClick={onGoToRegister}
                className="font-extrabold text-[#111111]"
              >
                Create account
              </button>
            </p>
          </div>
        </div>
      </section>
    </main>
  );
}

export default LoginPage;